<div class="alert alert-danger" role="alert">
    <strong>Página não localizada.</strong>
</div>