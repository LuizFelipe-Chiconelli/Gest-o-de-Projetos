<?php
/*--------------------------------------------------------------------
 |  CABEÇALHO PADRÃO
 |  – Aproveita baseUrl()  (helper core/Helper/utilits.php)
 |  – Usa Bootstrap LOCAL  (public/assets/bootstrap/)
 |  – Carrega jQuery + DataTables via CDN
 |-------------------------------------------------------------------*/
use Core\Library\Session;   // para mostrar opções de menu quando logado
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- METADADOS BÁSICOS -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>AtomPHP | FASM 2025</title>

    <!-- ÍCONE DO NAVEGADOR (favicon) -->
    <link rel="icon" type="image/png"
          href="<?= baseUrl()?>assets/img/AtomPHP-icone.png">

    <!-- BOOTSTRAP 5 – CSS local (já existe na pasta) -->
    <link rel="stylesheet"
          href="<?= baseUrl()?>assets/bootstrap/css/bootstrap.min.css">

    <!-- jQuery (necessário para DataTables) – CDN pequeno -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- DATATABLES (CSS/JS) + skin Bootstrap 5 -->
    <link  rel="stylesheet"
           href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <!-- BOOTSTRAP 5 – JS local (bundle já inclui Popper) -->
    <script src="<?= baseUrl()?>assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    
    <link rel="stylesheet" href="<?= baseUrl()?>assets/css/app.css">

</head>

<body>
<!-- ============================ NAVBAR ================================= -->
<header class="container-fluid">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">

            <!-- LOGO – link para a página inicial -->
            <a class="navbar-brand" href="<?= baseUrl()?>">
                <img src="<?= baseUrl()?>assets/img/AtomPHP-logo.png"
                     alt="Logo" width="90" height="90">
            </a>

            <!-- BOTÃO HAMBÚRGUER (mobile) -->
            <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- LINKS -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">

                    <!-- Links públicos -->
                    <li class="nav-item"><a class="nav-link" href="<?= baseUrl()?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Quem Somos</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Produtos/Serviços</a></li>

                    <?php if (Session::get('userId')): ?>
                        <!-- Menu quando LOGADO -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">
                                Usuário
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item" href="<?= baseUrl()?>login/signOut">Sair</a>
                                </li>

                                <?php if ((int)Session::get('userNivel') <= 20): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?= baseUrl()?>usuario">Usuários</a>
                                    </li>
                                <?php endif; ?>

                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item" href="<?= baseUrl()?>Usuario/formTrocarSenha">
                                        Trocar Senha
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <!-- Link login quando NÃO logado -->
                        <li class="nav-item">
                            <a class="nav-link" href="<?= baseUrl()?>Login">Área restrita</a>
                        </li>
                    <?php endif; ?>

                </ul>
            </div>
        </div>
    </nav>
</header>

<!-- MAIN container começa aqui (fecha no rodapé) -->
<main class="container">
