<?php
    /**
     * baseUrl
     *
     * @return string
     */
    function baseUrl()
    {
        return $_ENV['BASEURL'];
    }